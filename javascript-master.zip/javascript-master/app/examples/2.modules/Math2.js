var add = function(n1, n2) {
  return n1 + n2;
}

var divide = function(n1, n2) {
  return n1 / n2;
}

var subtract = function(n1, n2) {
  return n1 - n2;
}

var multiply = function(n1, n2) {
  return n1 * n2;
}

var PI = 3.1415;

export {
  add,
  divide,
  subtract,
  multiply,
  PI
}
