export default class Animal{
  constructor() {
    console.log("i am an animal");
  }
  getClassType() {
    return "Animal";
  }
}
