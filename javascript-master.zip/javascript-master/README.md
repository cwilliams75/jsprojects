# Javascript Course

![idea  (2)](https://user-images.githubusercontent.com/40702606/76909562-6d3e9f80-68a3-11ea-8217-ba49ac27cd14.png)

## Installation

1. [Install node] (https://nodejs.org/en/)
3. npm install
4. npm run devserver
5. Enjoy
