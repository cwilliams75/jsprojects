// Basic math formulaas
function addition(num1, num2){
  return -1;
}

function subtraction(num1, num2){
  return -1;
}

function multiplication(num1, num2){
  return -1;
}

function division(num1, num2){
  return -1;
}

// Area formulaas
function areaSquare(side){
  return -1;
}

function areaRectangle(length, width){
  return -1;
}

function areaParallelogram(base, height){
  return -1;
}

function areaTriangle(base, height){
  return -1;
}

function Circle(radius){
  return -1;
}

function Sphere(radius){
  return -1;
}

// Surface Area formulas
function surfaceAreaCube(side){
  return -1;
}

function surfaceAreaCylinder(radius, height){
  return -1;
}

// Perimeter formulas
function perimeterSquare(side){
  return -1;
}

function perimeterRectangle(length, height){
  return -1;
}

function perimeterTriangle(side1, side2, side3){
  return -1;
}

function perimeterCircle(diameter){
  return -1;
}

// Volume formulas
function volumeCube(side){
  return -1;
}

function volumeRectangular(length, width, height){
  return -1;
}

function volumeCylinder(radius, height){
  return -1;
}
